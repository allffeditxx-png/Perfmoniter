package com.allffeditxx.perfmonitor

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.net.TrafficStats
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MonitorService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: View? = null

    private lateinit var cpuBar: ProgressBar
    private lateinit var ramBar: ProgressBar
    private lateinit var storBar: ProgressBar
    private lateinit var batBar: ProgressBar
    private lateinit var cpuTxt: TextView
    private lateinit var ramTxt: TextView
    private lateinit var storTxt: TextView
    private lateinit var batTxt: TextView
    private lateinit var infoTxt: TextView

    private var lastIdle = 0L
    private var lastTotal = 0L
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        accessibilityButtonController.registerAccessibilityButtonCallback(
            object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) = toggle()
            })
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); super.onDestroy() }

    private var mini: TextView? = null

    private fun toggle() {
        when {
            panel != null -> { hide(); showMini() }
            mini != null -> hide()
            else -> show()
        }
    }

    private fun hide() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(miniTick)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        mini?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        mini = null
    }

    // Tiny, touch-through overlay: one TextView, updates every 2s, pauses when screen is off.
    private fun showMini() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(dp(4), dp(2), dp(4), dp(2))
            text = "..."
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(4); y = dp(4) }
        wm.addView(tv, lp)
        mini = tv
        lastTotal = 0L; lastT = 0L
        miniTick.run()
    }

    private val miniTick = object : Runnable {
        override fun run() {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isInteractive) updateMini()
            handler.postDelayed(this, 2000)
        }
    }

    private fun updateMini() {
        val tv = mini ?: return
        val cpu = cpuLoad()?.let { "$it%" } ?: cpuFreqs().let { f ->
            if (f.isEmpty()) "--" else "~" + f.map { it.first * 100 / it.second.coerceAtLeast(1) }.average().toInt() + "%"
        }
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = (mi.totalMem - mi.availMem) * 100 / mi.totalMem
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        val bat = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes()
        val down = if (lastT > 0 && now > lastT) (rx - lastRx) * 1000 / (now - lastT) / 1024 else 0
        lastRx = rx; lastT = now
        tv.text = "CPU $cpu RAM $ram%\n${temp}°C BAT $bat% ↓${down}K"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun row(root: LinearLayout, title: String): Pair<ProgressBar, TextView> {
        val t = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = title }
        val b = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(t)
        root.addView(b, LinearLayout.LayoutParams(-1, dp(10)).apply { bottomMargin = dp(10) })
        return b to t
    }

    private fun show() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE101820"))
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Perf Monitor"; setTextColor(Color.WHITE); textSize = 18f; setTypeface(null, Typeface.BOLD)
        })
        row(root, "CPU").let { cpuBar = it.first; cpuTxt = it.second }
        row(root, "RAM").let { ramBar = it.first; ramTxt = it.second }
        row(root, "Storage").let { storBar = it.first; storTxt = it.second }
        row(root, "Battery").let { batBar = it.first; batTxt = it.second }
        infoTxt = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; typeface = Typeface.MONOSPACE }
        root.addView(ScrollView(this).apply { addView(infoTxt) }, LinearLayout.LayoutParams(-1, dp(220)))
        root.addView(Button(this).apply { text = "Close"; setOnClickListener { hide() } })

        val lp = WindowManager.LayoutParams(
            dp(340), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(60) }

        wm.addView(root, lp)
        panel = root
        lastT = 0L
        tick.run()
    }

    private val tick = object : Runnable {
        override fun run() {
            if ((getSystemService(POWER_SERVICE) as PowerManager).isInteractive) update()
            handler.postDelayed(this, 1000)
        }
    }

    private fun update() {
        // CPU
        val load = cpuLoad()
        val freqs = cpuFreqs()
        if (load != null) { cpuBar.progress = load; cpuTxt.text = "CPU  $load%" }
        else if (freqs.isNotEmpty()) {
            val avg = freqs.map { it.first * 100 / it.second.coerceAtLeast(1) }.average().toInt()
            cpuBar.progress = avg; cpuTxt.text = "CPU  ~$avg% of max clock (Android blocks exact load)"
        } else cpuTxt.text = "CPU  unavailable on this device"

        // RAM
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val used = mi.totalMem - mi.availMem
        ramBar.progress = (used * 100 / mi.totalMem).toInt()
        ramTxt.text = "RAM  ${mb(used)} / ${mb(mi.totalMem)} MB"

        // Storage
        val sf = StatFs(Environment.getDataDirectory().path)
        val tot = sf.totalBytes; val usedS = tot - sf.availableBytes
        storBar.progress = (usedS * 100 / tot).toInt()
        storTxt.text = "Storage  ${gb(usedS)} / ${gb(tot)} GB"

        // Battery
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = lvl * 100 / scale
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val volt = b?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        batBar.progress = pct
        batTxt.text = "Battery  $pct%  ${if (charging) "(charging)" else ""}"

        // Network speed
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes(); val tx = TrafficStats.getTotalTxBytes()
        var down = 0L; var up = 0L
        if (lastT > 0 && now > lastT) {
            down = (rx - lastRx) * 1000 / (now - lastT); up = (tx - lastTx) * 1000 / (now - lastT)
        }
        lastRx = rx; lastTx = tx; lastT = now

        val thermal = if (Build.VERSION.SDK_INT >= 29)
            (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus.let {
                listOf("None", "Light", "Moderate", "Severe", "Critical", "Emergency", "Shutdown").getOrElse(it) { "?" }
            } else "n/a"

        val sb = StringBuilder()
        sb.append("Network  down ${kb(down)} KB/s  up ${kb(up)} KB/s\n")
        sb.append("Total    down ${mb(rx)} MB  up ${mb(tx)} MB (since boot)\n\n")
        sb.append("Battery temp  $temp °C\n")
        sb.append("Voltage       $volt mV\n")
        sb.append("Current       ${cur / 1000} mA\n")
        sb.append("Thermal state $thermal\n\n")
        if (freqs.isNotEmpty()) {
            sb.append("CPU cores (MHz)\n")
            freqs.forEachIndexed { i, f -> sb.append(" core$i  ${f.first / 1000} / ${f.second / 1000}\n") }
            sb.append("\n")
        }
        sb.append("Low memory    ${mi.lowMemory}\n")
        sb.append("Uptime        ${SystemClock.elapsedRealtime() / 60000} min\n")
        sb.append("Device        ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Android       ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Cores         ${Runtime.getRuntime().availableProcessors()}\n")
        sb.append("Screen        ${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels}\n")
        infoTxt.text = sb.toString()
    }

    private fun cpuLoad(): Int? = try {
        val l = File("/proc/stat").bufferedReader().use { it.readLine() }
            .trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        val idle = l[3] + l[4]; val total = l.sum()
        val r = if (lastTotal > 0 && total > lastTotal)
            (100 * (1.0 - (idle - lastIdle).toDouble() / (total - lastTotal))).toInt() else null
        lastIdle = idle; lastTotal = total
        r
    } catch (_: Exception) { null }

    private fun cpuFreqs(): List<Pair<Long, Long>> {
        val out = ArrayList<Pair<Long, Long>>()
        for (i in 0 until Runtime.getRuntime().availableProcessors()) {
            try {
                val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
                val cur = File(base + "scaling_cur_freq").readText().trim().toLong()
                val max = File(base + "cpuinfo_max_freq").readText().trim().toLong()
                out.add(cur to max)
            } catch (_: Exception) {}
        }
        return out
    }

    private fun mb(b: Long) = b / 1048576
    private fun gb(b: Long) = "%.1f".format(b / 1073741824.0)
    private fun kb(b: Long) = b / 1024
}
