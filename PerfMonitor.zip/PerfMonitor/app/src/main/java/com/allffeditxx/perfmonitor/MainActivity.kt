package com.allffeditxx.perfmonitor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        box.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Tap the button below\n2. Open Installed apps / Downloaded apps > Perf Monitor and turn it ON\n3. Tap the accessibility button: 1st tap = full panel, 2nd tap = tiny touch-through mini widget (top-left), 3rd tap = off."
        })
        box.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(box)
    }
}
